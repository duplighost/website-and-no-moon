# 10 — Current Code Atlas

Line numbers below refer to `01_CURRENT_WEBSITE_SOURCE_V67/no-moon/index.html`.

If you extract only the inline script, line numbers will differ because the HTML/CSS/header lines are removed.

| Area | Search term | Line in `no-moon/index.html` |
|---|---|---:|
| CHARACTERS data | `const CHARACTERS` | 1176 |
| v63 character visual metadata | `const CHARACTER_VISUALS_V63` | 1278 |
| BIOMES data | `const BIOMES` | 1327 |
| BIOME_MECHANICS map | `const BIOME_MECHANICS` | 1764 |
| ENEMY_TYPES data | `const ENEMY_TYPES` | 1945 |
| ITEM_POOL data | `const ITEM_POOL` | 2021 |
| ACHIEVEMENT_DEFS data | `const ACHIEVEMENT_DEFS` | 2304 |
| main state object | `const state =` | 2328 |
| makeDefaultSave | `function makeDefaultSave` | 2913 |
| safeWriteSave | `function safeWriteSave` | 2970 |
| refreshAchievementProgress | `function refreshAchievementProgress` | 2979 |
| commitRunSummary | `function commitRunSummary` | 3028 |
| render | `function render` | 3116 |
| updateOverlay | `function updateOverlay` | 3508 |
| showOverlay | `function showOverlay` | 3532 |
| hideOverlay | `function hideOverlay` | 3539 |
| createPlayer | `function createPlayer` | 3774 |
| startGame | `function startGame` | 5221 |
| damageEnemy | `function damageEnemy` | 5723 |
| damagePlayer | `function damagePlayer` | 5773 |
| firePlayerWeapon | `function firePlayerWeapon` | 5861 |
| updateGame | `function updateGame` | 6412 |
| drawPlayer | `function drawPlayer` | 7665 |
| buildDungeonRoom | `function buildDungeonRoom` | 9015 |
| generateLevel | `function generateLevel` | 9313 |
| syncActiveRoom | `function syncActiveRoom` | 9130 |
| setRoomCleared | `function setRoomCleared` | 9187 |
| updateEnemies | `function updateEnemies` | 9611 |
| drawBoundary | `function drawBoundary` | 9918 |
| drawHUD | `function drawHUD` | 10479 |
| v56 expressive systems pass | `function installV56ExpressiveSystemsPass` | 32550 |
| v61 visual intuition pass | `function installV61VisualIntuitionPass` | 38962 |
| v63 character art/live silhouettes pass | `function installV63CharacterArtLiveSilhouettes` | 39661 |
| v64 living laws/UI/boss/haven pass | `function installV64LivingLawsUiBossHavenPass` | 39738 |
| v65 first-real-game polish/title art pass | `function installV65FirstRealGamePolishPass` | 40454 |
| v66 real title flow/progress audit pass | `function installV66RealTitleFlowProgressAuditPass` | 40667 |
| v67 hazard UI/ending clarity pass | `function installV67HazardUiEndingClarityPass` | 41098 |

## Main source file size

- `no-moon/index.html`: 41,156 lines.

## Build tag anchor

Search for:

`qual.hazard-literacy-ui-ending-clarity.2026-05-10.v67`

The final patch sets `state.buildTag` to that value.

## Safe edit guidance

For small UI/copy/CSS changes, direct edits may be cleanest.

For gameplay/HUD/combat behavior, use a guarded internal patch layer near the bottom of the file and wrap existing closure-local functions.

## Current v67 behavior summary

v67 is visual/UI/copy polish. It does not intentionally change:

- player radius
- movement
- aiming
- firing
- weapon logic
- item mechanics
- enemy AI
- room generation
- boss HP/damage balance
- Safe Haven trophy schema
- title assets
- v66 title splash flow

It adds/changes:

- visual hazard language overlays
- cleaner HUD top chip
- unified route-key dock
- gear/audio dock positioning
- low HP signal
- Sun win copy clarity
- character-select start affordance
