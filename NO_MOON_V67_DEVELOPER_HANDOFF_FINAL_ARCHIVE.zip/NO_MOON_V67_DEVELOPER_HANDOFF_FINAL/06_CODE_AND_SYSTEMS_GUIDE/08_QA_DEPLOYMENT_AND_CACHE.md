# 08 — QA, Deployment, and Cache Guide

## Validation command

From the archive root:

```bash
python3 07_TOOLS/validate_handoff.py
```

The script checks:

- inline game JS extraction
- `node --check` on inline game JS
- `node --check` on game service worker
- `node --check` on root service worker
- current deploy zip integrity

## Manual smoke test checklist

Desktop:

1. Open `/no-moon/`.
2. Confirm title splash appears first.
3. Click `Choose Passenger`.
4. Confirm four character cards appear.
5. Select character and click `Descend as ...`.
6. Confirm play starts and overlay hides.
7. Confirm gear/audio dock does not overlap Moon Debt/minimap.
8. Confirm no stray `SUNKEY 0/1` at start.
9. Trigger `state.v67ForceHazardLegend()` and inspect hazard readability.
10. Trigger `state.v67ForceLowHp()` and inspect subtle low HP signal.
11. Trigger `state.v67ForceSunWinCopy()` and inspect Sun win copy.

Mobile:

1. Test title splash.
2. Test character select scrolling.
3. Confirm sticky descend/action row is usable.
4. Confirm SFX/BGM buttons are not cluttering character select.
5. Start gameplay and inspect touch controls/UI crowding.

Progress:

1. Run `state.v66ProgressAudit()`.
2. Run `state.v66AchievementAudit()`.
3. Confirm trophies persist after reload if unlocked.
4. Confirm counts do not double-increment after death/win/retry.

## Service workers

There are two relevant workers:

- `/no-moon/no-moon-sw.js` — real No Moon worker, cache `no-moon-hazard-ui-ending-clarity-v67`.
- `/no-moon-sw.js` — root-level cleanup worker to clear stale No Moon caches and unregister itself.

When making a new build, bump the game worker cache name. If adding art assets, include them in the game worker's asset list.

## Browser cache notes

If a user sees an old version after upload:

- Try hard refresh.
- Try incognito/private window.
- Clear site storage for the domain.
- Confirm `state.buildTag` in the console.
- Confirm service-worker cache name is the expected new one.

## Packaging

The deploy zip should contain root files directly, not a nested wrapper folder. The top level should include:

- `index.html`
- `book.html`
- `no-moon.html`
- `no-moon-sw.js`
- `_redirects`
- `assets/`
- `no-moon/`

## Honest QA limit

Automated/static smoke validation is not a substitute for human playtesting. v67 passed syntax/package/targeted smoke tests, but a full route-through-everything human QA pass is still needed.
