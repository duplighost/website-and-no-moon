# 09 — Known Risks and Next Work

## Known risks / watch list

These are not necessarily confirmed bugs in v67, but they are the highest-risk areas to watch during testing.

### UI overlap

v64-v67 improved UI lanes, key chips, gear dock, low HP, and card behavior, but No Moon has many layered HUD systems. Continue to screenshot/report any overlap, especially on mobile and during boss/reward moments.

### Hazard readability

v67 adds slow/damage visual grammar. Playtest whether players actually learn it. If not, tune shape/color/animation before adding text.

### Progress/achievement counts

v66 added audits and duplicate-summary guard. Continue to test death/win/retry/return loops and achievement persistence.

### Boss anti-melt feel

v64's boss first-breath cap and melt response should be tuned with real high-DPS builds. The goal is boss presence, not making damage feel fake.

### Late-game economy/sustain

The game may still become too generous late-game. Watch repair drops, stars, items, trophies, debt/reward economy, and whether HP sustain outpaces danger.

### Item/copy audit

Some older item descriptions or visible labels may still carry outdated phrasing or tone. Copy cleanup can be done later if IDs are preserved.

## Highest-value next patch

**v68 — Playtest Hardening / UI Collision Audit / Economy First Trim**

Suggested scope:

1. Add optional UI collision debug overlay/logging.
2. Tune v67 hazard-language colors/animation based on real play.
3. First pass late-game pickup/repair economy reduction.
4. Tune boss anti-melt if it feels too invisible or too punitive.
5. Continue mobile UI cleanup.

## Larger future features

- Deeper biome identity objects/hazards.
- Enemy room profiles by role grammar.
- More polished ending moon chamber where the player performs the ending without losing control.
- Safe Haven diorama expansion.
- More clear but still stylish win/loss/result screens.

## What not to do next

- Do not add more currencies.
- Do not restart the character redesign unless Alex explicitly requests it.
- Do not add a giant tutorial/prose system.
- Do not yank the camera for bosses.
- Do not refactor the whole project into a framework unless that becomes a separate committed project.
