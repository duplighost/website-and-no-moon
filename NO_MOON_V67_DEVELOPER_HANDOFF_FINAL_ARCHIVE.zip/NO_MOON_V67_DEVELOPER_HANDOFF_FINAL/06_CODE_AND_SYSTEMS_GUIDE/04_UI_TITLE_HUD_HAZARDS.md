# 04 — UI, Title Flow, HUD, and Hazard Literacy

## Title flow

v66 introduced a real two-stage title flow:

1. **Cold-load title splash** — title art and `Choose Passenger` button. No character cards.
2. **Character select** — character cards and `Descend as ...` action.

The title splash is a front door, not the gameplay hub. It should not automatically appear after death, win, retry, or Safe Haven return.

The title art is CSS/DOM overlay-backed, not canvas gameplay art.

## Character select

v63 added character portrait art and live-form previews. v67 makes the action row sticky and improves mobile character select so a player is less likely to select a character without noticing the `Descend as ...` button.

Current UX problem to keep testing: on mobile, character cards are tall. The sticky action row helps, but real user testing matters.

## HUD direction

v67 cleans the top-left HUD and suppresses some legacy route-key chips. It draws:

- stable room/biome info
- HP/Guard/Grafts
- low-HP signal when HP is 1
- unified route-key dock only when relevant
- gear/SFX/BGM controls repositioned below Moon Debt/minimap area when possible

## UI overlap philosophy

UI should have lanes and priorities:

- Top center: boss/route/final ceremony.
- Top left: player/room state.
- Top right: persistent chips/buttons, but avoid Moon Debt/minimap collision.
- Right side: item/achievement cards, lane-managed.
- World space: door, pickup, hazard, breach, shrine/trophy feedback.

If a future patch adds UI, it must reserve space and avoid mobile crowding.

## Hazard literacy

v67 adds visual grammar over existing room hazards. It does not change hazard mechanics.

Important current language:

- Harmless decorative stars/sigils/arena rings: atmospheric only; no v67 damage/slow overlay.
- Slow/soft zones: cool dashed/ripple language.
- Damaging cores: warmer inner ring and radial ticks.
- Pulse/ritual hazards: charge/active circular danger language.
- Lane hazards: rectangular rail/charge marks.

The goal is for players to understand what hurts, what slows, and what is decorative without adding combat text.

## Low HP signal

When HP is at 1, v67 adds a subtle HUD/player signal. If guard/shield is still available, it should not scream panic-red; it should warn without becoming annoying.

## Sun ending clarity

v67 updates the Sun-route win overlay to make clear that the Sun has been set down and that Safe Haven receives the Sun Head. The copy should remain poetic but not so ambiguous that the player cannot tell whether they won.
