# 02 — Code Architecture

## Static website shape

The current source root is `01_CURRENT_WEBSITE_SOURCE_V67/`.

Important files:

- `index.html` — Qualiacology home page with No Moon promotional section.
- `book.html` — book page.
- `no-moon.html` — small redirect/entry helper to `/no-moon/`.
- `no-moon/index.html` — the actual game.
- `no-moon/no-moon-sw.js` — game service worker/cache.
- `no-moon-sw.js` — root-level cleanup worker for stale No Moon caches.
- `assets/no-moon/characters/*.webp` — v63 character portrait assets.
- `assets/no-moon/title/*.webp` — v65/v66 title art assets.

## Game architecture

The game is primarily a single large HTML file:

`01_CURRENT_WEBSITE_SOURCE_V67/no-moon/index.html`

The file contains CSS, DOM overlay markup, canvas setup, and a huge inline JavaScript closure. The current file is about 41,156 lines.

Most gameplay functions are **closure-local**. They are not safely reachable from a separate script appended after the main script. This is the most important architecture fact.

## Patch stack architecture

The game has accumulated many internal patch layers. Modern high-impact patches are implemented as guarded internal IIFEs near the bottom of the main script. They wrap closure-local functions such as `pushMessage`, `drawHUD`, `updateGame`, `damageEnemy`, `drawBoundary`, `showOverlay`, and `updateOverlay`.

Current modern patch stack:

- v56 — expressive systems / active relics / transformations.
- v61 — visual intuition / low-combat-text conversion.
- v63 — character art and live silhouettes.
- v64 — living laws: UI lanes, boss presence, Safe Haven trophies, biome/perch improvements.
- v65 — title art and Safe Haven center seal.
- v66 — real title splash flow and progress/achievement audit.
- v67 — hazard literacy, UI cleanup, low HP signal, route-key dock, Sun ending clarity.

## Where to insert future gameplay patches

Insert future patch IIFEs inside `no-moon/index.html` near the bottom of the main script, before the final `renderCodexStats();` call and before the script closure ends.

Do not attach a new external gameplay script and expect it to access closure-local functions. It generally will not.

## Safe wrapping pattern

```js
(function installV68SomePass(){
  const V68_VERSION = 'qual.some-pass.2026-xx-xx.v68';
  if (!state || state.v68SomePass?.installed) return;
  const sys = state.v68SomePass = { installed: true, version: V68_VERSION };

  if (typeof drawHUD === 'function' && !drawHUD.__v68SomePass) {
    const baseDrawHUD = drawHUD;
    drawHUD = function drawHUDV68SomePass() {
      const out = baseDrawHUD.apply(this, arguments);
      try {
        // draw optional overlay
      } catch (err) {
        try { console.warn('[v68SomePass]', err); } catch (_) {}
      }
      return out;
    };
    drawHUD.__v68SomePass = true;
  }

  state.buildTag = V68_VERSION;
})();
```

## Direct-edit vs wrapper guidance

Direct edits are reasonable for:

- Static website copy.
- CSS-only layout polish.
- Visible names/descriptions where IDs remain unchanged.
- Service worker cache lists/names.
- Obvious typos.

Wrappers/internal patch layers are safer for:

- HUD/UI behavior.
- Combat text suppression.
- Hazard overlays.
- Boss anti-melt/boss presence.
- Progress audits/canonicalization.
- Save migration guards.
- Debug helpers.

## Validation

Run:

```bash
python3 07_TOOLS/validate_handoff.py
```

The script extracts inline JS from `no-moon/index.html`, runs `node --check`, checks service workers, and verifies deploy zip integrity.
