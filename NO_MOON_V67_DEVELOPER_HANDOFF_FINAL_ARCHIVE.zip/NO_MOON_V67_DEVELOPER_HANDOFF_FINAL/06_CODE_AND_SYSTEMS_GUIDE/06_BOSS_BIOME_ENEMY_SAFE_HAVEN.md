# 06 — Bosses, Biomes, Enemies, Perches, and Safe Haven

## Boss presence

Current boss-presence direction is: no camera yank, no control theft.

v64 added:

- first-breath anti-melt damage cap
- DPS/melt response tracking
- boss metadata
- arena rings
- boss shield pulse/add pressure

Future boss work should tune these systems through real play. If a boss melts too fast, prefer short damage caps and behavior changes over huge HP sponge buffs.

## Biome identity

v64 layered biome family visuals over existing biome data. v67 helps hazards read better. The next biome pass should deepen each family with a few strong visual objects and clear hazard behaviors, not paragraphs of explanation.

## Enemy role grammar

Enemy rooms should feel like combinations of roles, not random enemy soup. Role examples:

- Chaser: forces movement.
- Shooter: adds bullet pressure.
- Sniper: punishes stillness with a telegraphed sightline.
- Turret: controls lanes/angles.
- Brute: occupies space.
- Hexer: changes safe zones.
- Elite hybrid: combines pressure types.

## Perch sockets

The game has perch/socket logic from earlier passes, and v64 improves perched Long Candle sniper behavior into a fairer telegraph cycle:

`cooldown -> aiming telegraph -> fire -> recover`

This should remain readable. Avoid off-screen same-tick sniper shots.

## Safe Haven

Safe Haven is a room that should physically remember progress.

Current trophy direction:

- Moon Head appears after Moon completion.
- Sun Head appears after Sun completion.
- Center seal reacts as trophies accumulate.
- These should stay visual and persistent, not noisy popup rewards.

Future Safe Haven expansion ideas:

- character stations
- route doors
- Moonkey/Sunkey altar slots
- relic station
- Star Market / Risk Desk table
- run memorial marks
- final chamber gate
