# 05 — Save, Progress, Achievements, and Counts

## Save key

Current save key:

`noMoonSave_v1`

Save handling is in:

- `makeDefaultSave`
- `safeReadSave`
- `safeWriteSave`
- `loadSave`
- `commitRunSummary`
- `refreshAchievementProgress`

## Save contents

The save tracks:

- selected character
- unlocked characters
- highest biome reached
- lifetime stats: kills, deaths, wins, runs, secrets, biomes cleared, items chosen/found, breakables, time played
- achievements
- later trophy fields such as Moon Head / Sun Head via patch canonicalization

## v66 progress audit

v66 added canonicalization and audit helpers to reduce count/save weirdness:

- Ensures lifetime counters exist and are numeric.
- Ensures achievements have records.
- Preserves achievement IDs while allowing visible names to change.
- Guards against duplicate terminal run-summary counting.
- Restores achievement side-card display that could be swallowed by stricter text suppression.

## Current debug helpers

See `03_CURRENT_NOTES_AND_VALIDATION/V66_DEBUG_HELPERS.md` and `V67_DEBUG_HELPERS.md`.

Important helpers include:

- `state.v66ProgressAudit()`
- `state.v66AchievementAudit()`
- `state.v66SaveNow()`
- `state.v67Debug()`
- `state.v67ForceLowHp()`
- `state.v67ForceHazardLegend()`
- `state.v67ForceSunWinCopy()`

## Achievement IDs vs visible names

Do not casually rename achievement IDs. If an achievement's visible name changes, keep the internal ID stable unless writing a migration.

Example: v66/v67 changed a visible achievement name from older mouth-imagery wording to `Hundred Marks` while keeping the internal ID `kills_100`.

## Things to test after progress changes

- Run count increments once per run.
- Death count increments once per death.
- Win count increments once per win.
- Achievements persist after reload.
- Achievement cards display when unlocked.
- Moon/Sun trophy flags persist after reload.
- Retry and character select do not reset lifetime counters.
- Title splash does not run count or reset state by merely appearing.
