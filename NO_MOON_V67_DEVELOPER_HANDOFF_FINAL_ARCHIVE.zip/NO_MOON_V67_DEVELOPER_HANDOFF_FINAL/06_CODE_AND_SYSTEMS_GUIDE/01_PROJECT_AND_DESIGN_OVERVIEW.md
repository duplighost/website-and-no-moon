# 01 — Project and Design Overview

## What No Moon is

**No Moon** is a browser-based, static-site, canvas/WebAudio twin-stick roguelike under the Qualiacology website. The public website root includes broader Qualiacology/book/music/site content, and the game lives under `/no-moon/`.

The current game is a dark, arcade-like dungeon descent with four moon-headed player characters, room-by-room combat, draft/item systems, stars and Moon Debt, boss/miniboss encounters, route keys, Safe Haven trophies, biome/floor identity, and a cinematic title flow.

It is heavily inspired by the feel of room-based action roguelikes, but the project direction is now its own thing: a readable, stylish, low-text, visually expressive dungeon game.

## Current player-facing direction

The current direction is:

- Less text during combat.
- More visual feedback: rings, glows, particles, HUD pulses, trophy objects, door/room/world changes.
- Moon-headed Passenger characters instead of generic ships/tanks.
- Clearer floor hazard language.
- Boss presence without camera control theft.
- Safe Haven as a room that physically remembers completed routes.
- Title art as a real cold-load front door before character select.

## Current playable characters

| Character | Title | Weapon | Role |
|---|---|---|---|
| Rook | Bulwark Diver | shotgun/scatter furnace | heavy, close burst, tanky |
| Nyx | Razor Pilgrim | fast needle | fast, piercing, fragile |
| Sol | Relay Saint | twin relay | balanced, guarded, steady |
| Mire | Thorn Cantor | paired homing spores | secret sense, homing pressure |

All four are currently framed as moon-headed Passengers with distinct live silhouettes and portrait art.

## Current v67 focus

v67 is a testing-polish build. It addresses issues seen during real play:

- It clarifies which ground circles/marks slow the player, hurt the player, or are decorative.
- It cleans up HUD and route-key display.
- It moves the gear/SFX/BGM controls away from Moon Debt/minimap overlap.
- It adds a subtle one-HP warning.
- It makes the Sun route win copy clearer.
- It makes character select more intuitive by keeping the start/action row sticky.

## Website integration

The site is a static website. The playable game is served at `/no-moon/`. The current deploy zip includes the complete website root, not just the game.

There is no backend, package manager, or build step. The current workflow is manual static-file editing, validation, zipping, and upload.
