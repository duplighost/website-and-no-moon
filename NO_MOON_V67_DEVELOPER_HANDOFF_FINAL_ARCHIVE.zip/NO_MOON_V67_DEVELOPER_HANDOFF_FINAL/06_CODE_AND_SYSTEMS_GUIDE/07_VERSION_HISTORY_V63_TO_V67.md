# 07 — Version History: v63 to v67

This archive includes notes from v63-v67. Older deploy binaries are omitted; the notes are here for context.

## v63 — Character Art + Live Silhouettes

- Added portrait WebP assets for Rook, Nyx, Sol, and Mire.
- Replaced the busy symbolic character-card direction with image-based cards.
- Added live top-down silhouettes for each character.
- Fixed Mire's visual language to show paired spore behavior.

## v64 — Living Laws / UI / Boss / Safe Haven

- Added UI lane governance and stricter combat-text suppression.
- Added compact floor badges.
- Added Safe Haven Moon Head and Sun Head trophies.
- Added boss anti-melt/presence metadata and arena rings.
- Added biome identity overlays.
- Improved perched sniper fairness.

## v65 — First Real Game Polish / Title Art

- Added title-art assets.
- Used title art behind the title/select overlay.
- Improved mobile opener/card compression.
- Added Safe Haven center seal.

## v66 — Real Title Flow + Progress Audit

- Split title into cold-load splash and character select.
- Protected death/win/Safe Haven loop from accidental splash display.
- Added progress/achievement canonicalization and audits.
- Restored achievement side-card behavior that strict text suppression could intercept.

## v67 — Hazard Literacy + UI/Ending Clarity

- Added visual hazard grammar: slow vs damage vs decorative.
- Repositioned gear/audio dock.
- Replaced odd starting Sunkey chip with unified route-key dock when relevant.
- Cleaned top-left HUD and low-HP signal.
- Clarified Sun route win copy.
- Improved character-select start affordance.

## Current state

v67 is the current source of truth. Start from v67 for new work.
