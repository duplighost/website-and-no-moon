# 03 — Gameplay Systems Reference

## Run structure

The player chooses one of four characters, then starts a room-based descent. The game uses rooms, doors, room clear state, enemy spawns, pickups, bosses, route systems, and special branches. The player moves and fires in twin-stick style using keyboard/mouse or touch/mobile controls.

## Characters

Characters are defined in `CHARACTERS` in `no-moon/index.html`.

- `rook`: high HP, shotgun/scatter, slower, heavy close burst.
- `nyx`: low HP, fast, needle weapon, piercing, high fire rate.
- `sol`: balanced, twin weapon, starts with a shield/guard layer.
- `mire`: paired spore/homing weapon, secret sense, lower burst.

Character IDs should be preserved because save/progress/UI/debug systems assume them.

## Player object

The player object is created by `createPlayer(template)`. Important properties include:

- `x`, `y`, `vx`, `vy`
- `r` — radius; keep at 17 unless intentionally redesigning collision.
- `aimX`, `aimY`, `aimAngle`
- `hp`, `maxHp`
- `shield`, `shieldMax`
- `speed`, `damage`, `fireDelay`
- `modules`, `perks`, character template data

## Weapons

Weapon behavior is in `firePlayerWeapon(player, ax, ay)`.

- Rook shotgun/scatter fires multiple pellets.
- Nyx needle fires fast single shots and can pierce.
- Sol twin fires paired shots.
- Mire spore fires paired homing/organic shots.

The v63/v67 visuals are meant to represent these weapons without changing weapon logic.

## Items, grafts, pickups

Items live in `ITEM_POOL`. Item IDs should be preserved for saves/progress unless a migration is written.

The current design direction is to make pickup feedback physical and visual: pickups should disappear, fly inward, pulse the HUD, or otherwise show that they were collected. Avoid adding central combat prose for ordinary pickups.

## Rooms and doors

Room generation and transitions are anchored by:

- `generateLevel`
- `buildDungeonRoom`
- `syncActiveRoom`
- `setRoomCleared`
- `tryDoorTransition`
- `drawBoundary`

`setRoomCleared` is an important hook for visual door unlocks and room-clear behavior. Door state should come from actual room state, not from text messages.

## Enemies

Base enemy definitions are in `ENEMY_TYPES`:

| Type | Display | Role |
|---|---|---|
| skitter | Pewling | pressure/chaser |
| gunner | Censer | projectile pressure |
| charger | Ramwraith | dash disruption |
| turret | Lectern | lane/angle control |
| brute | Ox-Warden | space occupation |
| sniper | Long Candle | sightline/telegraph pressure |
| hexer | Antiphon | zone/control pressure |
| myrmidon | Crown-Sworn | elite hybrid |

Enemy update behavior lives in `updateEnemies`. Enemy creation uses `createEnemy` and generation helpers.

## Bosses

Current boss presence is mostly from v64:

- Boss metadata is attached for first-breath damage cap and DPS/melt response.
- Arena rings are drawn in world space.
- Boss presence should not move the camera.
- Bosses should feel present through room behavior, bars, rings, phase pressure, and limited anti-melt logic.

Any boss tuning should avoid long invulnerability. The better pattern is short damage capping plus behavior/phase response.

## Biomes

Biomes are data-driven via `BIOMES` and `BIOME_MECHANICS`. v64/v67 add visual identity and badge behavior on top of existing generation.

Biome direction:

- Root/thorn floors: snare/root/ambush language.
- Mire/spore floors: rain, puddles, fog/spore slow language.
- Glass floors: shard/glass/volatile marks.
- Forge/cinder/sun floors: heat pulses and lanes.
- Archive/null floors: sightlines/perches/ritual pressure.

## Safe Haven

Safe Haven should function as an in-world memory room, not merely a menu. v64 added Moon Head and Sun Head trophies. v65 added a center seal between them. v67 preserves this system.

Trophies should appear physically in Safe Haven after relevant completions, not as noisy unlock popups.
