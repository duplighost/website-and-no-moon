# v65 Validation Log

## Static validation

- Extracted inline JavaScript from `/no-moon/index.html`.
- `node --check` inline game JS: PASS.
- `node --check no-moon/no-moon-sw.js`: PASS.
- `node --check no-moon-sw.js`: PASS.
- Deploy zip integrity: PASS.
- SHA256 generated.

## Runtime smoke tests

Headless Chromium was run with the container’s managed URL-blocking policy temporarily removed, then the policy was restored afterward.

### Desktop title smoke

- Page loaded: PASS.
- Build tag: `qual.first-real-game-polish-title-art.2026-05-08.v65`.
- `state.v65FirstRealGamePolish` installed: PASS.
- Overlay class `v65TitleArt` applied on title screen: PASS.
- Four character cards rendered: PASS.
- Title copy shortened and visible: PASS.
- Desktop screenshot generated: `v65_title_desktop.png`.

### Mobile title smoke

- Mobile title rendered: PASS.
- Overlay class `v65TitleArt` applied: PASS.
- Selected card expanded: PASS.
- Non-selected cards collapsed smaller: PASS.
- Mobile screenshot generated: `v65_title_mobile.png`.

### Safe Haven trophy smoke

- Start button entered play mode: PASS.
- `state.v65UnlockTrophyPair()` unlocked Moon/Sun trophies through v64 helpers: PASS.
- Safe Haven trophy diorama rendered: PASS.
- v65 center seal rendered: PASS.
- Screenshot generated: `v65_play_haven_trophies.png`.

## Runtime console

- No console errors captured in the Chromium smoke run.

## Scope not fully human-tested

I did not complete a full human end-to-end playthrough through every biome, item, transformation, branch, final path, boss, and mobile-control scenario. v65-specific systems passed syntax, package, service-worker asset, and targeted runtime smoke tests.
