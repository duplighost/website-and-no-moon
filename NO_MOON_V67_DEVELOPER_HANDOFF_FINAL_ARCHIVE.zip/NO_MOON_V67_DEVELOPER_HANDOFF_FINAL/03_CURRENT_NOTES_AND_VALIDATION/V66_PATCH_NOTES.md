# No Moon v66 — Real Title Flow + Progress Audit

Base: `no-moon-qualiacology-v65-first-real-game-polish.zip`

Build tag: `qual.real-title-flow-progress-audit.2026-05-09.v66`

Service-worker cache: `no-moon-real-title-flow-progress-audit-v66`

## Main goal

v66 turns the v65 cover-art background into an actual two-stage title flow and audits progress/achievement state so the new front door does not disturb death, win, retry, Safe Haven, or save counts.

## Main additions

### Cinematic title splash before character select

- Cold page load now opens on a clean splash panel over the title art.
- Splash mode hides the character cards and title audio buttons so the cover art can breathe.
- The splash button reads `Choose Passenger` and advances to character select instead of starting a run.
- Character select remains the existing v65/v63 card flow after the splash.
- Normal later character-select openings skip the splash by default.

### Loop-safe death/win behavior

- The title splash is a front door, not a hub replacement.
- Death/win overlays remain separate.
- Returning to Safe Haven remains in-world and does not show the splash.
- A later manual/explicit title call can still show the splash through debug or an explicit title request.

### Progress and achievement audit

- Added save canonicalization to ensure lifetime fields, character unlocks, trophy flags, and achievement records are present and sane.
- Refreshes achievement progress against current save values after load and before writes.
- Adds a run-summary duplicate guard so one run should not count death/win summaries twice if stacked handoff code fires again.
- Restores achievement side-cards under v64's strict combat text system by pushing them into the v61/v64 lane-managed card path before v64 suppresses the text.
- Renamed the visible achievement `Hundred Teeth` to `Hundred Marks` while preserving the achievement id `kills_100`.

### Debug helpers

- `state.v66Debug()`
- `state.v66ProgressAudit()`
- `state.v66AchievementAudit()`
- `state.v66SaveNow()`
- `state.v66ForceTitleSplash()`
- `state.v66ForceCharacterSelect()`
- `state.v66TitleSplash(true|false)`

## Files changed

- `/no-moon/index.html`
- `/no-moon/no-moon-sw.js`
- `/no-moon-sw.js`
- `/index.html`

## Files added

No new runtime art assets were added. v66 reuses the v65 title art and v63 character portraits.
