# v64 Validation Log

## Static validation

- Inline game JavaScript extracted from `/no-moon/index.html`.
- `node --check` inline game JS: PASS.
- `node --check no-moon/no-moon-sw.js`: PASS.
- `node --check no-moon-sw.js`: PASS.
- Deploy ZIP integrity: PASS.

## Runtime smoke tests

Headless Chromium was run with the container's managed URL-blocking policy temporarily removed, then the policy was restored afterward.

### General v64 smoke

- Page loaded: PASS.
- `state.buildTag`: `qual.living-laws-ui-boss-haven.2026-05-08.v64`.
- `state.v64Debug()` loaded and returned installed state.
- Start button entered play mode.
- `state.v64ForceTextStress()` suppressed five routine combat messages.
- `state.v64UnlockMoonHead()` and `state.v64UnlockSunHead()` unlocked persistent trophy flags.
- Safe Haven diorama rendered.
- v60 bottom Safe Haven ledger was suppressed so it no longer overlaps mobile route panels.
- Desktop and mobile screenshots generated.

Notes: Chromium reported expected localhost/blob manifest warnings for `start_url` and `scope` in the smoke environment. No game runtime exceptions were captured.

### Boss/Night Ferry smoke

- `state.v59GoSkyBoss()` generated the Starless Sky branch boss room.
- Night Ferry boss spawned.
- v64 boss presence attached to `v59NightFerry`.
- `state.v64BossMeltTest()` triggered the melt-response state.
- Boss arena ring rendered.
- Misleading Warden/Bellway copy was suppressed during the Night Ferry fight.
- Boss smoke screenshot generated.
- No runtime errors captured.

## Scope not fully human-tested

I did not perform a full human end-to-end playthrough through every biome, item, transformation, branch, final path, and mobile control path. The v64-specific systems passed syntax, package, and targeted runtime smoke tests.
