# No Moon v65 — First Real Game Polish / Title Art Front Door

Base: `no-moon-qualiacology-v64-living-laws-ui-boss-haven.zip`

Build tag: `qual.first-real-game-polish-title-art.2026-05-08.v65`

Service-worker cache: `no-moon-first-real-game-polish-v65`

## Main goal

v65 smooths the v64 living-laws build into something that feels more like a finished first game: a real title screen, cleaner mobile opener, stricter low-text presentation, safer cache behavior, and a more beautiful Safe Haven trophy center.

## Main additions

### Cover-art title screen

- Added responsive title-screen WebP assets:
  - `assets/no-moon/title/no-moon-title-desktop.webp`
  - `assets/no-moon/title/no-moon-title-mobile.webp`
  - `assets/no-moon/title/no-moon-title-poster.webp`
- The title overlay now uses the cover art as a darkened, readable background instead of a plain gradient.
- The title text/copy was shortened so the art and character cards do the work.
- The CSS keeps the overlay readable on desktop and mobile with dark gradients and glassier panels.

### Cleaner opener copy

- Title copy now reads:

  `Choose a moon-headed Passenger. Descend through rooms that remember what you take. Come back alive and Safe Haven changes.`

- The start button remains tied to the selected character: `Descend as Rook/Nyx/Sol/Mire`.
- The title eyebrow now reads `moon-headed dungeon descent`.

### Mobile character-card compression

- On mobile title screens, the selected card stays expanded.
- Non-selected cards collapse their long description/stats/tags so all four Passengers are less punishing to scroll through.
- Portraits are slightly brightened and lifted for readability.

### Safe Haven center seal

- Added a subtle world-space center seal between the Moon Head and Sun Head trophies.
- It remains faint when trophies are missing, glows when one trophy is present, and becomes a brighter eclipse-like center when both Moon Head and Sun Head are unlocked.
- This is visual-only and does not change gameplay.

### v64 cleanup retained

- Keeps v64 strict combat text mode.
- Keeps v64 icon floor badges.
- Keeps v64 lane-managed side cards.
- Keeps v64 boss presence / first-breath anti-melt.
- Keeps v64 fair perched sniper telegraphs.
- Keeps v64 Safe Haven Moon/Sun trophy diorama.
- Replaces the remaining debug-only “teeth” phrase with “splinters.”

### Cache/service-worker fix

- Updated `/no-moon/no-moon-sw.js` to cache the new title art assets.
- Bumped cache name to avoid stale title backgrounds or stale v64 code.
- Updated root cleanup service worker comment to v65.

## Files changed

- `/no-moon/index.html`
- `/no-moon/no-moon-sw.js`
- `/no-moon-sw.js`
- `/index.html`

## Files added

- `/assets/no-moon/title/no-moon-title-desktop.webp`
- `/assets/no-moon/title/no-moon-title-mobile.webp`
- `/assets/no-moon/title/no-moon-title-poster.webp`
