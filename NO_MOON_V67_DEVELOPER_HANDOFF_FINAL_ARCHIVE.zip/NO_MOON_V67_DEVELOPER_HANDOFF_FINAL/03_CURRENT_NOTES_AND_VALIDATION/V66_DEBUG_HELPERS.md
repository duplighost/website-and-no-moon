# v66 Debug Helpers

Open DevTools on the No Moon page and use:

```js
state.v66Debug()
```

Returns v66 version, build tag, title-flow state, progress audit, run-summary guard state, and nested v65/v64 debug data.

```js
state.v66ProgressAudit()
```

Returns lifetime stats, highest biome reached, selected character, trophy flags, and achievement progress/unlock state.

```js
state.v66AchievementAudit()
```

Returns achievement count and per-achievement records.

```js
state.v66SaveNow()
```

Canonicalizes and writes the current save.

```js
state.v66ForceTitleSplash()
```

Opens the title overlay in splash mode.

```js
state.v66ForceCharacterSelect()
```

Opens the title overlay directly to character select.

```js
state.v66TitleSplash(false)
state.v66TitleSplash(true)
```

Toggles the splash stage for testing.

Older useful helpers still work:

```js
state.v65Debug()
state.v65UnlockTrophyPair()
state.v64Debug()
state.v64TextAudit()
state.v64BossMeltTest()
state.v63ForceCharacter('mire')
```
