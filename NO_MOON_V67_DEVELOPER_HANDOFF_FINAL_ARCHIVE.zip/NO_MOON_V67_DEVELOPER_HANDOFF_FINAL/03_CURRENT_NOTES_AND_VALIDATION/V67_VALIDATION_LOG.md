# v67 Validation Log

## Static validation

- Extracted inline JavaScript from `/no-moon/index.html`.
- `node --check` inline game JS: PASS.
- `node --check no-moon/no-moon-sw.js`: PASS.
- `node --check no-moon-sw.js`: PASS.

## Runtime smoke tests

Headless Chromium was run against a local HTTP server using the system Chromium binary. Playwright service workers were blocked for smoke testing so the local v67 source, not a cached service-worker response, was inspected.

### Desktop title/select/start smoke

- Page loaded into the v66/v67 title splash: PASS.
- Build tag: `qual.hazard-literacy-ui-ending-clarity.2026-05-10.v67`.
- `state.v67HazardUiEndingClarity` installed: PASS.
- Splash button text: `Choose Passenger`.
- Clicking `Choose Passenger` switched to character select: PASS.
- Four character cards rendered: PASS.
- Sticky action row was present in character select: PASS.
- Clicking `Descend as Rook` entered play mode: PASS.
- Overlay was visually hidden after gameplay start: PASS.

### HUD/UI smoke

- Clean top-left HUD chip rendered with biome/room and HP/Guard/Grafts: PASS.
- Gear dock rendered below Moon Debt/minimap region in gameplay: PASS.
- Unified route-key dock stayed hidden at boot/start with 0 keys: PASS.
- Unified route-key dock appeared after debug-added Moon/Sun key counts: PASS.

### Hazard literacy smoke

- `state.v67ForceHazardLegend()` added demonstration hazards to the active room: PASS.
- Slow-only fog displayed cool ripple language: PASS.
- Spore hazard displayed slow ring plus inner danger ring: PASS.
- Pulse hazard displayed warm charge/danger language: PASS.
- Decorative floor/star markings remained visually separate from damage/slow marks: PASS by inspection.

### Low HP smoke

- `state.v67ForceLowHp()` set player HP to 1: PASS.
- Top-left HP line changed to warning color and chip border gained subtle warning pulse: PASS.
- Player low-health ring displayed: PASS.

### Sun win clarity smoke

- `state.v67ForceSunWinCopy()` opened Sun-route win overlay: PASS.
- Title changed to `THE SUN HAS BEEN SET DOWN`: PASS.
- Eyebrow changed to `sun route cleared`: PASS.
- Body copy clearly says the Sun fell and that Safe Haven receives the Sun Head: PASS.
- Sun Head trophy flag was set through existing trophy path: PASS.

### Mobile smoke

- Mobile title splash loaded with v67 installed: PASS.
- Mobile character select rendered four cards after `Choose Passenger`: PASS.
- Sticky `Descend as Rook` button remained available while scrolling: PASS.
- Mobile selected-card clutter was removed after the final CSS adjustment: PASS.
- Mobile SFX/BGM buttons are hidden during character select to keep the top clean: PASS.

## Runtime console

- No page errors were captured in the smoke report.
- Console warnings captured were expected browser WebAudio/autoplay warnings and Playwright service-worker blocking warnings.

## Scope not fully human-tested

I did not complete a full human end-to-end playthrough through every biome, boss, item, transformation, branch, ending, and mobile-control case. v67-specific systems passed syntax, package, desktop/mobile title-flow, HUD, hazard-literacy, low-HP, and Sun-ending smoke tests.
