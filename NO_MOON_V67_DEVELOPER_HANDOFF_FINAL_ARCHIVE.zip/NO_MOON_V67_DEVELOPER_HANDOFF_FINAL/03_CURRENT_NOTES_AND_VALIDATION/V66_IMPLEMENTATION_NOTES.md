# v66 Implementation Notes

v66 is implemented as a late internal patch IIFE inside `/no-moon/index.html`, inserted before the final `renderCodexStats();` call. This keeps access to closure-local functions and avoids rewriting the combat/gameplay engine.

## Title flow

v66 adds a small title-flow state object:

```js
state.v66RealTitleFlowProgressAudit.flow = {
  stage: 'splash' | 'select',
  reason,
  bootSplashShown,
  explicitSplashRequest,
  lastStageChange
}
```

The page boots into `stage: 'splash'`. The splash is CSS/DOM only. The capture-phase click handler on `startBtn` intercepts the old launch button listener when the title is in splash mode, prevents the run from starting, and switches to `stage: 'select'`.

After the stage changes to select, the original start button behavior is allowed through unchanged, so the existing `startGame(state.selectedCharId)` path remains intact.

## Overlay safety

- `showOverlay('title')` after the boot splash defaults to select mode, not splash mode.
- `showOverlay('dead')` and `showOverlay('win')` clear v66 splash/select classes.
- `hideOverlay()` clears v66 splash/select classes.
- The title splash does not touch player state, movement, rooms, boss logic, or Safe Haven.

## Progress safety

v66 canonicalizes `state.save` after load and before writes. It ensures:

- lifetime counters are finite non-negative numbers
- all current characters have unlock flags
- all achievements exist and have current progress/goal/unlocked values
- trophy flags exist
- selected character id is valid

A duplicate run-summary guard wraps `commitRunSummary`. It is reset in the `startGame` wrapper. This is intentionally conservative: one run should only write one terminal summary.

## Achievement side cards

v64 strict text suppression intercepts `Achievement:` messages before v61 can make a side-card. v66 wraps `pushMessage` outside v64 and directly pushes achievement cards into `state.v61VisualIntuition.itemCards`, so v64's lane-managed card drawer can display them without central combat prose.

## Gameplay safety

v66 intentionally does not change:

- player radius
- movement
- aiming
- firing
- weapon logic
- item logic
- boss HP/damage balance
- room generation
- enemy AI
- Safe Haven trophy unlock rules
- title art assets
