# v64 Implementation Notes

v64 is implemented as an internal patch IIFE inside `/no-moon/index.html`, inserted before the final `renderCodexStats();` call so it can access closure-local game functions.

The pass intentionally avoids rewriting the core room graph, movement, hitbox, weapon, item, relic, or transformation systems.

## Important wrappers

- `pushMessage`: v64 text audit and suppression layer after v61.
- `render`: temporary suppression of old floor badge, v61 fixed side cards, and v60 bottom Safe Haven ledger; v64 redraws floor badge and side cards through lane slots.
- `drawBoundary`: draws biome identity, Safe Haven trophies, and boss arena rings in world space.
- `updateGame`: retags current room identity, normalizes perches, and maintains boss presence/melt effects.
- `damageEnemy`: applies boss first-breath cap and melt-response cap.
- `commitRunSummary`: ensures trophy state exists and unlocks Moon/Sun heads on appropriate wins.
- `populateRoomEnemies` / `buildDungeonRoom`: attach biome identity and role/perch metadata.

## Perch sniper surgery

The old perched sniper block inside `updateEnemies` was directly replaced. This was safer than trying to patch it after the fact because the old code fired the warning beam and the projectile in the same tick.

The new behavior is a small state machine:

```txt
cooldown -> aiming telegraph -> fire -> recover -> cooldown
```

## Save compatibility

Old saves are merged safely. `state.save.trophies` is added lazily with:

```js
{ moonHead: false, sunHead: false }
```

Existing lifetime wins and Sun-path clear storage can backfill trophies.

## Known notes

- The ending moon chamber from the brainstorm was not added in this pass. v64 focuses on UI, boss presence, biome identity, perches, and Safe Haven memory.
- The biome pass is mostly visual/metadata in v64. It intentionally avoids heavy new hazard logic to reduce risk before upload/testing.
