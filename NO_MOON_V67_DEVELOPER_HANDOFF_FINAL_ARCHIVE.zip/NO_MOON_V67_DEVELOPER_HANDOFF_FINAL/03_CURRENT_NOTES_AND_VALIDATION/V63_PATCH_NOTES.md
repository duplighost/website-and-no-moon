# No Moon v63 — Character Art / Live Silhouettes

Base build: **No Moon v62 — Passenger / Hull Character Identity**

Build tag:

```txt
qual.character-art-live-silhouettes.2026-05-08.v63
```

Service-worker cache:

```txt
no-moon-character-art-live-silhouettes-v63
```

## Main goal

v62 made the Passenger/Hull idea intellectually clear. v63 makes it visually land harder: the character select screen now uses the new moon-headed character art, and the live combat avatar is drawn as a simplified top-down moon-headed cloak-body instead of a ship/tank-looking machine.

## Changed files

- `no-moon/index.html`
- `no-moon/no-moon-sw.js`
- root `no-moon-sw.js`
- root `index.html`
- added `assets/no-moon/characters/rook-portrait.webp`
- added `assets/no-moon/characters/nyx-portrait.webp`
- added `assets/no-moon/characters/sol-portrait.webp`
- added `assets/no-moon/characters/mire-portrait.webp`

## Character select

- Replaced the busier v62 symbolic portrait area with cleaner image-based cards.
- Added cropped Passenger art for all four characters:
  - Rook
  - Nyx
  - Sol
  - Mire
- Added a small code-drawn top-down live-form preview on every card.
- The live-form preview shows the weapon identity:
  - Rook: scatter furnace / shotgun bloom.
  - Nyx: single needle rail.
  - Sol: paired relay ports.
  - Mire: **paired spore vents and two green motes**, not a single beam.
- Removed the awkward v62 “Passenger / Hull kind” line and replaced it with a cleaner live-form label.
- Changed the stat label from `Bite` to `Output` in character cards.

## Live in-game player visuals

- Kept the existing hitbox, stats, movement, collision, weapon logic, relics, items, and transformations.
- `player.r` stays `17`.
- Refactored the live draw path so the player reads as a compact top-down moon-headed combat body:
  - center broken moon head/core
  - cloak/body trailing behind
  - front emitter matched to weapon
  - muzzle flash matched to weapon
  - shield/orbital/transformation wrappers preserved
- Rook now reads less like a tank and more like a broad reliquary/tomb-body with a scatter furnace.
- Nyx now reads as a narrow needle pilgrim / scalpel silhouette.
- Sol now reads as a symmetrical relay guardian with paired ports.
- Mire now reads as an organic thorn/shrine body with paired spore vents.

## Balance/gameplay

No intentional balance changes. Visual accent colors were retuned to better match the character art, but the mechanical fields were preserved:

- Rook: shotgun, max hull 9, damage 1.0, fire delay 0.36.
- Nyx: needle, max hull 5, damage 0.72, fire delay 0.10.
- Sol: twin, max hull 7, damage 0.93, fire delay 0.22.
- Mire: spore, max hull 6, damage 0.88, fire delay 0.28.

## Site/game page

- Updated the website No Moon section to mention v63 character art and live silhouettes.
- Updated build notes from v62 Passenger/Hull identity to v63 character art.

## Cache

- Updated No Moon scoped service worker cache to v63.
- Added the four character portrait WebP assets to the game worker precache list.
- Added a cache-first fetch path for the character portrait assets.
- Updated the root cleanup worker comment to v63.
