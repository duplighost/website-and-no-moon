# v65 Debug Helpers

Open DevTools on the No Moon page and use:

```js
state.v65Debug()
```

Returns v65 version, build tag, title-art state, trophy state, v65 stats, and nested v64/v63 debug information.

```js
state.v65TitleArt(true)
state.v65TitleArt(false)
```

Toggles title-art mode for the title overlay.

```js
state.v65UnlockTrophyPair()
```

Unlocks Moon Head and Sun Head for Safe Haven visual testing.

```js
state.v65ForceTitle()
```

Returns to the title overlay and reapplies v65 title polish.

Existing useful helpers still work:

```js
state.v64Debug()
state.v64TextAudit()
state.v64ForceTextStress()
state.v64BossMeltTest()
state.v63ForceCharacter('mire')
state.v59GoSkyBoss()
```
