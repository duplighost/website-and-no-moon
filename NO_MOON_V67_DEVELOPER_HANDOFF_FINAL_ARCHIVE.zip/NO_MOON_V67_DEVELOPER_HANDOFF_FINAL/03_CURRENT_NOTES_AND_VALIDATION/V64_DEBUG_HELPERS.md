# v64 Debug Helpers

Open DevTools on the No Moon page and use:

```js
state.v64Debug()
```

Returns build tag, reservations, suppressed text, trophies, current room identity, boss presence state, and v64 stats.

```js
state.v64TextAudit()
```

Shows recent suppressed text and leak-log entries.

```js
state.v64ToggleCombatText('strict')
state.v64ToggleCombatText('minimal')
state.v64ToggleCombatText('debug')
```

Switches active-combat text policy.

```js
state.v64ForceTextStress()
```

Pushes several sample messages to verify suppression and major-title behavior.

```js
state.v64UnlockMoonHead()
state.v64UnlockSunHead()
```

Unlocks Safe Haven trophies for visual testing.

```js
state.v64BossMeltTest()
```

Triggers the current live boss's v64 melt-response if a boss is present.

Existing useful helpers from earlier builds still work, including:

```js
state.v59GoSkyBoss()
state.v63ForceCharacter('mire')
state.v61TestVisualCues()
```
