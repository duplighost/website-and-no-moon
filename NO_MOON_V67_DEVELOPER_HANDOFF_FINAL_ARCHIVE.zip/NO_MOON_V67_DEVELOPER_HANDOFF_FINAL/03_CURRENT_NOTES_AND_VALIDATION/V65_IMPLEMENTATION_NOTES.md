# v65 Implementation Notes

v65 is implemented as an internal patch IIFE inside `/no-moon/index.html`, inserted before the final `renderCodexStats();` call so it can access closure-local functions.

## Why this approach

The game is a large single-file HTML/JS build with many closure-local functions. The safest path was to preserve v64 systems and add a small late wrapper pass instead of rewriting title/menu, movement, combat, bosses, room generation, or save logic.

## Important wrappers

- `updateOverlay`: reapplies v65 title copy and title art class after existing overlay patch layers.
- `showOverlay`: ensures the title art class is applied whenever the title screen opens.
- `hideOverlay`: removes the title art class when gameplay starts.
- `drawBoundary`: draws the Safe Haven center seal after the v64 Safe Haven trophy diorama.

## Title art

The title art is CSS-backed rather than canvas-backed. This means the art does not affect combat rendering or gameplay performance after the overlay closes.

Assets:

- desktop: `1600x900`, ~200 KB
- mobile: `900x1600`, ~300 KB
- poster: `960x1440`, ~250 KB

The poster asset is cached for future title/share/capsule work and ensures the service worker asset list stays valid.

## Mobile opener behavior

The selected character card remains expanded. Non-selected cards collapse detail rows on mobile only. This keeps the rich character identity while making the title screen less like a mile-long menu.

## Safe Haven center seal

The center seal reads existing `state.save.trophies` and draws only in the Safe Haven entry room during active play. It does not add collision, rewards, text, interactions, or route logic.

## Gameplay safety

v65 intentionally does not change:

- player radius
- movement
- aiming
- firing
- weapon logic
- item logic
- boss HP/damage logic
- room generation
- enemy AI
- save schema beyond v64 trophies
