# No Moon v63 Validation Log

## Static validation

Passed:

```bash
node --check /mnt/data/work_v63/extracted-game.js
node --check no-moon/no-moon-sw.js
node --check no-moon-sw.js
```

Deploy ZIP integrity passed:

```bash
unzip -t no-moon-qualiacology-v63-character-art-live-silhouettes.zip
```

## Runtime smoke test

A Playwright smoke test executed the game HTML with the character art assets fulfilled from the local filesystem.

Notes: the system Chromium policy in this container blocks direct `file://` and `127.0.0.1` page navigation, so the smoke harness used `page.set_content()` with a `<base>` URL and routed the local portrait assets into the browser. That still executed the game JavaScript, loaded the character images, clicked through character select, entered play mode, and used real mouse input for shooting checks.

Passed checks:

- `state.buildTag` returned `qual.character-art-live-silhouettes.2026-05-08.v63`.
- `state.v63CharacterArtLiveSilhouettes.installed` returned `true`.
- 4 character portrait images rendered.
- 4 top-down live preview SVGs rendered.
- All four WebP portraits loaded with natural width `520`.
- Start button entered `play` mode.
- `player.r` remained `17`.
- `state.v63ForceCharacter('rook')`, `'nyx'`, `'sol'`, and `'mire'` all returned the expected character ids/weapons/stats.
- Mire retained `weapon: spore`, `fireDelay: 0.28`, and `damage: 0.88`.
- Mire’s visual metadata reports `shotCountVisual: 2` and `liveName: Paired spore cantor`.
- Mouse-input firing check for Mire produced 2 player bullets.
- Mouse-input firing check for Rook produced 5 player bullets.
- Mobile character select rendered 4 art panels.
- No console errors.
- No page errors.
- No bad responses in the smoke harness.

## Smoke result excerpt

```json
{
  "buildTag": "qual.character-art-live-silhouettes.2026-05-08.v63",
  "v63Installed": true,
  "cardCount": 4,
  "miniCount": 4,
  "modeAfterStart": "play",
  "playerRadius": 17,
  "mireMouseBulletCount": 2,
  "rookMouseBulletCount": 5,
  "consoleErrors": [],
  "pageErrors": [],
  "badResponses": []
}
```

## Screenshots captured

Included in this notes package:

- `screenshots/v63_character_select_desktop.png`
- `screenshots/v63_character_select_mobile.png`
- `screenshots/v63_mire_twin_spore_desktop.png`

## Limits

I did not do a full human end-to-end playthrough through every biome, boss, branch, item, transformation, shrine ending, and mobile-control route. The v63-specific character card, live avatar, and shooting systems passed targeted runtime checks.
