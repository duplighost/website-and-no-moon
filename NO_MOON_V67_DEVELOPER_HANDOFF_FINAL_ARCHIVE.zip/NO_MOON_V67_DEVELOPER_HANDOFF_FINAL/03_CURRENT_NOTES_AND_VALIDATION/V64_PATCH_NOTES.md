# No Moon v64 — Living Laws / UI, Boss, Haven

Base: `no-moon-qualiacology-v63-character-art-live-silhouettes.zip`

Build tag: `qual.living-laws-ui-boss-haven.2026-05-08.v64`

Service-worker cache: `no-moon-living-laws-ui-boss-haven-v64`

## Main additions

### UI lane governor and low-text audit

- Added `state.v64LivingLaws`, a shared UI/system surface for the new pass.
- Added stricter active-combat text classification after v61.
- Converted/suppressed more combat prose:
  - door/reward chatter
  - repair/guard chatter
  - active relic chatter
  - star/debt chatter
  - Star Thief / coin-breathing ambient text
  - misleading Warden copy during the Night Ferry branch boss
- Added `state.v64TextAudit()` so remaining text leaks can be inspected.
- Added `state.v64ToggleCombatText('strict' | 'minimal' | 'debug')`.

### Icon floor badges

- Suppressed the old condition badge during v64 active play.
- Replaced it with a compact icon/title badge.
- Badge examples include ROOT, THORN, MIRE, GLASS, CINDER, ARCHIVE, NULL, AURIC, SKY, and ASTERVEIL.
- The badge now participates in the v64 reservation/slot system so it is less likely to crowd the active slot or route panels.

### Lane-managed item cards

- v64 temporarily disables the v61 fixed side-card draw during render and redraws item/achievement side cards through lane slots.
- Desktop allows up to three side cards.
- Mobile allows one compact card.
- Cards queue/skip drawing when there is no safe slot instead of stacking over reserved UI.

### Safe Haven diorama

- Added persistent `state.save.trophies` with:
  - `moonHead`
  - `sunHead`
- Added debug unlocks:
  - `state.v64UnlockMoonHead()`
  - `state.v64UnlockSunHead()`
- Added a physical Safe Haven trophy diorama:
  - broken Moon Head pedestal
  - fractured Sun Head pedestal
  - dim locked versions before unlock
  - proximity glow response
- Suppressed the old v60 bottom-center Safe Haven ledger during v64 render, because it overlapped mobile route panels. The room now remembers through objects instead of another bottom box.

### Boss presence and anti-melt

- Added boss presence metadata for boss-like enemies.
- Added short first-breath damage capping so bosses do not vanish before they exist.
- Added melt-response state:
  - temporary boss shield pulse
  - arena-ring emphasis
  - small add pressure
- Added `state.v64BossMeltTest()` debug helper.
- Added world-space boss arena rings without camera yank or control theft.

### Night Ferry cleanup

- Suppressed misleading Graven Warden / Bellway Gaoler copy when the Starless Sky branch boss is actually the Night Ferry.
- The Night Ferry smoke check now shows only the correct Night Ferry boss title/bar.

### Biome identity overlay

- Added biome family identity mapping layered over existing biome data.
- Visual-only overlays now make rooms read more physically:
  - root/thorn tendrils
  - wet/sky flowing bands
  - glass shard lines
  - forge heat seams
  - archive/gold long-line architecture
- This does not replace the existing room generator or tile architecture.

### Enemy role grammar / perches

- Added role metadata for existing enemies:
  - pressure chaser
  - strafing shooter
  - dash disruptor
  - lane turret
  - space brute
  - telegraph sniper
  - zone controller
  - elite hybrid
- Normalized existing perch metadata with biome-family skins.
- Reworked perched Long Candle sniper logic from same-tick beam+shot into:
  - cooldown
  - aiming telegraph
  - fire
  - recover
- This preserves the enemy, but makes the shot feel fair instead of like a bookkeeping sniper.

## Files changed

- `/no-moon/index.html`
- `/no-moon/no-moon-sw.js`
- `/no-moon-sw.js`
- `/index.html`

No external art assets were added in v64.
