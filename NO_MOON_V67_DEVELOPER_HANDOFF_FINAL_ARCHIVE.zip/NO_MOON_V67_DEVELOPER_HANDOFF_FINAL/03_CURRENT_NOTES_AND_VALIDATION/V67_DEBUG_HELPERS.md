# v67 Debug Helpers

Open DevTools on the No Moon page and use:

```js
state.v67Debug()
```

Returns v67 version/config/stats, route-key counts, current room hazard summaries, player HP/guard status, Sun-ending state, and nested v66 debug data.

```js
state.v67ForceHazardLegend()
```

Adds three demonstration hazards to the current room: slow-only fog, spore slow-with-danger-core, and pulse damage ring. This is for visual validation of hazard literacy.

```js
state.v67ForceLowHp()
```

Sets the player to 1 HP so the subtle low-health HUD/player signal can be inspected.

```js
state.v67ForceSunWinCopy()
```

Forces the Sun-route win overlay copy for review and validation.

Older useful helpers still work:

```js
state.v66Debug()
state.v66ProgressAudit()
state.v66AchievementAudit()
state.v66ForceTitleSplash()
state.v66ForceCharacterSelect()
state.v65UnlockTrophyPair()
state.v64Debug()
state.v64TextAudit()
state.v64BossMeltTest()
state.v63ForceCharacter('mire')
```
