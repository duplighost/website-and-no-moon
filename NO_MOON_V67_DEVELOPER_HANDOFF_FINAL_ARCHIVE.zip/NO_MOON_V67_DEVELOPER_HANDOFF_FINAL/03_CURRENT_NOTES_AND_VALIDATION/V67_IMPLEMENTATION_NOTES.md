# v67 Implementation Notes

v67 is implemented as a late internal patch IIFE inside `/no-moon/index.html`, inserted before the final `renderCodexStats();` call. This preserves access to closure-local functions while avoiding gameplay rewrites.

## Hazard language

The patch wraps `drawAmbientWorld(level)` and draws additional readability overlays for entries in the active room's `room.hazards` array.

It does not change hazard behavior. Existing hit/slow/damage logic remains untouched. v67 only adds a consistent visual layer:

- `fog`: cool dashed ripple language for slow/obscure effects.
- `spore`, `snare`, `lotus`: cool outer slow ring plus warm inner danger ring.
- `pulse`, `ritual`: charge/active circular danger marks.
- `lane`: rectangular rail/charge marks.

Decorative stars, arena rings, item circles, and harmless room markings are not classified as hazards and do not get the v67 damage/slow marks.

## HUD cleanup

v67 disables old route-key HUD chips each update/draw cycle:

- `state.v30MoonkeySystem.config.MOONKEY_HUD = false`
- `state.v43SunkeyDifficultyClaritySystem.config.SUNKEY_HUD_CHIP = false`
- `state.v43SunkeyRouteSupplementSystem.config.SUNKEY_HUD = false`

A unified route-key dock is drawn only when the run has Moon/Sun key relevance. This avoids showing `SUNKEY 0/1` at the very beginning when Moonkey has not been introduced.

The top-left HUD chip is redrawn with stable room/biome + HP/Guard/Grafts information, and v67 temporarily suppresses `state.buildName` while inner HUD wrappers render to avoid top-right UI name collisions.

## Gear/audio dock

The gameplay gear/SFX/BGM controls are repositioned after render based on `gameplayUiLayout().moonChip`, keeping the buttons below Moon Debt/minimap when possible. Mobile title-select audio buttons are hidden only during character select; they reappear in gameplay.

## Low HP

`drawHUD` adds a subtle low-HP signal if `state.player.hp <= 1` and `state.player.maxHp > 1`. The signal is designed to be visible without becoming a constant red alarm.

## Character select

v67 adds CSS and click affordances rather than changing the start-game path. The existing `startGame(state.selectedCharId)` flow remains untouched.

## Sun ending clarity

v67 observes `state._v39SunVictoryStarted` to add a brief golden collapse pulse. It then wraps `updateOverlay` / `showOverlay('win')` to replace the Sun-route win copy when `state._v39SunPathCompletedThisWin` is true. It calls `state.v64UnlockSunHead()` when available, but does not change the trophy system itself.

## Gameplay safety

v67 intentionally does not change:

- player radius
- movement
- aiming
- firing
- weapon logic
- item logic
- boss HP/damage balance
- room generation
- enemy AI
- Safe Haven Moon/Sun trophy schema
- title art assets
- v66 title splash flow
