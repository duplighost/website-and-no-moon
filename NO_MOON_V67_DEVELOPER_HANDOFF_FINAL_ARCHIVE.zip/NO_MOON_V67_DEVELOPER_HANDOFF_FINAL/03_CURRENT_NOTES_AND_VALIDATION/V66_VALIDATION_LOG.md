# v66 Validation Log

## Static validation

- Extracted inline JavaScript from `/no-moon/index.html`.
- `node --check` inline game JS: PASS.
- `node --check no-moon/no-moon-sw.js`: PASS.
- `node --check no-moon-sw.js`: PASS.

## Runtime smoke tests

Headless Chromium was run against a local HTTP server. The container's managed Chromium URL-blocking policy was temporarily moved out of the managed policy directory for the smoke run and restored afterward.

### Desktop splash smoke

- Page loaded: PASS.
- Build tag: `qual.real-title-flow-progress-audit.2026-05-09.v66`.
- `state.v66RealTitleFlowProgressAudit` installed: PASS.
- Overlay classes: `v65TitleArt`, `v66TitleSplash`.
- Character grid hidden during splash: PASS.
- Splash button text: `Choose Passenger`.
- Audio buttons hidden during splash: PASS.
- Desktop splash screenshot generated: `v66_title_splash_desktop.png`.

### Desktop select/start smoke

- Clicking `Choose Passenger` switched to character select: PASS.
- Overlay classes after click: `v65TitleArt`, `v66TitleSelect`.
- Four character cards visible: PASS.
- Start button changed to `Descend as Rook`: PASS.
- Clicking start entered play mode: PASS.
- Overlay hidden after gameplay start: PASS.
- Desktop character-select screenshot generated: `v66_character_select_desktop.png`.
- Play smoke screenshot generated: `v66_play_smoke.png`.

### Later title/select behavior

- `state.v66ForceCharacterSelect()` opens select mode, not splash: PASS.
- `state.v66ForceTitleSplash()` opens explicit splash mode: PASS.

### Mobile smoke

- Mobile page loaded into splash mode: PASS.
- Mobile splash hides character cards and audio buttons: PASS.
- Mobile `Choose Passenger` advances to select mode: PASS.
- Four mobile character cards rendered after select: PASS.
- Mobile screenshots generated: `v66_title_splash_mobile.png`, `v66_character_select_mobile.png`.

### Progress audit smoke

- `state.v66ProgressAudit()` returned finite lifetime values, 8 achievement records, and trophy flags.
- Achievement visible name `Hundred Marks` is present while id remains `kills_100`.
- Runtime showed `achievementCardsRestored: 1` during start-run smoke, confirming the restored side-card path is active.

## Runtime console

- No page errors captured.
- Console warnings captured were expected browser WebAudio autoplay warnings.

## Scope not fully human-tested

I did not complete a full human end-to-end playthrough through every biome, boss, item, transformation, branch, ending, and mobile-control case. v66-specific systems passed syntax, package, title-flow, mobile, and targeted progress-audit smoke tests.
