# No Moon v67 — Hazard Literacy + UI/Ending Clarity

Base: `no-moon-qualiacology-v66-real-title-flow-progress-audit.zip`

Build tag: `qual.hazard-literacy-ui-ending-clarity.2026-05-10.v67`

Service-worker cache: `no-moon-hazard-ui-ending-clarity-v67`

## Main goal

v67 is a testing-polish pass aimed at the issues seen during real play: confusing ground marks, persistent UI overlaps, odd Sunkey/Moonkey display, low-health readability, unclear Sun-route victory, and character-select start friction.

## Main additions

### Hazard literacy / ground-language pass

- Adds a visual grammar overlay on top of existing room hazards without changing hazard damage, slow, collision, room generation, or enemy logic.
- Slow-only hazards now get cool dashed ripple rings and drifting motes.
- Hazards with damaging cores now get a warmer inner ring and short radial tick marks.
- Pulse/ritual/lane hazards get stronger active/charge outlines and progress arcs.
- Harmless floor sigils, boss arena rings, item-spawn flourishes, and decorative star outlines are intentionally left alone so they do not inherit the damage marks.

### Cleaner HUD and route-key behavior

- Suppresses the legacy separate Moonkey/Sunkey HUD chips and replaces them with one unified route-key dock when route keys actually matter.
- The start of the run no longer shows the odd `SUNKEY 0/1` chip by itself.
- The top-left HUD chip is simplified into room/biome + HP/Guard/Grafts, preventing pickup/build names from being stuffed under persistent UI.
- Gear/SFX/BGM dock is repositioned during gameplay so it does not collide with Moon Debt/minimap chips.

### Low-health signal

- When the player has 1 HP left, the top-left chip gains a subtle warm warning border and HP text color.
- The player gets a very soft ring signal.
- If guard/shield is still protecting the player, the signal leans cooler instead of panic-red.

### Character-select start affordance

- The start/action row is sticky in character select.
- Selected cards get clearer emphasis on desktop.
- On compact/mobile screens, noisy selected-label clutter is hidden and the `Descend as ...` button stays available.
- The mobile SFX/BGM buttons are hidden during character select to keep the top clear; they still return in gameplay.

### Clearer Sun-route victory

- Adds a brief golden Sun-collapse visual pulse when the Sun victory state starts.
- Rewords the Sun win overlay so the player knows the Sun was actually defeated without flattening the ending into blunt arcade copy.
- Unlocks/refreshes the Sun Head trophy path through the existing Safe Haven trophy system.

## Files changed

- `/no-moon/index.html`
- `/no-moon/no-moon-sw.js`
- `/no-moon-sw.js`
- `/index.html`

## Files added

No new runtime art assets were added. v67 reuses the v65 title art and v63 character portraits.
