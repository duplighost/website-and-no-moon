# Design Brief

## Core identity

No Moon should feel like a dark arcade dungeon game with a strong visual identity, not a text-heavy lore document. The game should explain itself primarily through motion, light, rings, object changes, and HUD behavior.

## Current character direction

The playable cast are moon-headed Passengers. They should not read as random ships or tanks. The live sprites stay compact and readable, while character-select art gives them fuller identity.

- Rook: heavy cyan reliquary/scatter furnace.
- Nyx: narrow violet needle pilgrim.
- Sol: ivory/gold twin relay guardian.
- Mire: green thorn cantor with paired spore vents.

## Visual language principles

- Decorative sigils can be beautiful, but they must not imply damage unless they actually hurt.
- Damage areas should have a warm/active core or tick language.
- Slow areas should read cooler/softer.
- Boss presence should come from room behavior, arena ring, bar, lighting, and phase changes, not camera theft.
- Safe Haven rewards should physically appear as room objects.

## Text philosophy

Text is allowed in:

- title/character select
- draft/shop/choice screens
- death/win/results screens
- pause/codex/help
- rare boss/route ceremony

Text should be minimized in active combat. Routine combat feedback should be visual.

## Tone

The tone should be strange, beautiful, dark, and stylish. It should not become a wall of exposition. Ambiguity is welcome, but the player should still understand whether they won, died, unlocked something, took damage, or entered a dangerous area.
