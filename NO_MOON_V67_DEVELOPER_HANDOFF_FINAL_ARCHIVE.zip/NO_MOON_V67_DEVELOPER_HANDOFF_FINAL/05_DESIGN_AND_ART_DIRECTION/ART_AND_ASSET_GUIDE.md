# Art and Asset Guide

## Current runtime art assets

Character portraits:

- `assets/no-moon/characters/rook-portrait.webp`
- `assets/no-moon/characters/nyx-portrait.webp`
- `assets/no-moon/characters/sol-portrait.webp`
- `assets/no-moon/characters/mire-portrait.webp`

Title art:

- `assets/no-moon/title/no-moon-title-desktop.webp`
- `assets/no-moon/title/no-moon-title-mobile.webp`
- `assets/no-moon/title/no-moon-title-poster.webp`

## Asset handling

If adding new runtime assets:

1. Put them under `assets/no-moon/...`.
2. Add them to `/no-moon/no-moon-sw.js` `ASSETS` if they should be cached.
3. Bump the service-worker cache name.
4. Validate that the service worker installs successfully.

## Title screen

The title splash uses CSS background art and DOM overlay classes, not canvas gameplay rendering. This keeps the title presentation low-risk.

## Character select

Character cards use portrait art plus live-form previews. Do not return to the older busy symbolic card system. The cleaner portrait/card direction is the current design base.

## Future art direction

Good future additions:

- More distinct biome floor/prop objects.
- Stronger Safe Haven diorama objects.
- More polished Moon Head / Sun Head if canvas primitives no longer feel special enough.
- Final moon chamber art/lighting.

Avoid adding high-resolution art that bloats mobile load without clear payoff.
