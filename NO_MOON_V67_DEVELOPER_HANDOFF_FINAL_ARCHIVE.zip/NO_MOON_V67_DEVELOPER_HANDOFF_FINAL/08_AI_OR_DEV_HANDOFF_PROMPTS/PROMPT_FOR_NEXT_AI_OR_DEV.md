# Prompt for Next AI or Developer

```text
You are helping Alex continue work on No Moon, a static-site browser roguelike under the Qualiacology website.

You have been given the final context-free No Moon v67 developer handoff archive. Do not assume access to any previous chat context.

Current source of truth:
- Editable source: 01_CURRENT_WEBSITE_SOURCE_V67/
- Current deploy zip: 02_CURRENT_DEPLOY_PACKAGE/no-moon-qualiacology-v67-hazard-literacy-ui-ending-clarity.zip

Current build tag:
qual.hazard-literacy-ui-ending-clarity.2026-05-10.v67

Current game service-worker cache:
no-moon-hazard-ui-ending-clarity-v67

Older deploy packages are not included in this archive. Historical notes from v63-v67 are included only for context. Start new work from the included v67 source unless Alex explicitly asks for rollback/comparison.

Before editing, read:
1. 00_READ_FIRST/README_START_HERE.md
2. 00_READ_FIRST/SOURCE_OF_TRUTH_AND_RULES.md
3. 06_CODE_AND_SYSTEMS_GUIDE/02_CODE_ARCHITECTURE.md
4. 06_CODE_AND_SYSTEMS_GUIDE/03_GAMEPLAY_SYSTEMS_REFERENCE.md
5. 06_CODE_AND_SYSTEMS_GUIDE/08_QA_DEPLOYMENT_AND_CACHE.md
6. 06_CODE_AND_SYSTEMS_GUIDE/09_KNOWN_RISKS_AND_NEXT_WORK.md

Critical architecture fact:
The game is mostly one huge inline JS closure in no-moon/index.html. Most gameplay functions are closure-local. Do not append external gameplay scripts and expect to reach them. Add guarded internal patch layers near the bottom before final renderCodexStats(); if patching gameplay/HUD/combat behavior.

Critical design rules:
- No camera/control theft.
- Combat prose should be minimal.
- Preserve player movement/radius/weapons/IDs unless specifically changing those systems.
- Preserve character, item, and achievement IDs unless writing migrations.
- Mobile UI readability matters.
- Visual clarity should carry the game: hazards, rewards, trophies, bosses, routes.
- Safe Haven should remember progress physically through room objects.

Before returning work:
- Run python3 07_TOOLS/validate_handoff.py.
- Validate no-moon/index.html inline JS and service workers.
- Bump build tag/cache names for any new build.
- Produce patch notes, implementation notes, debug-helper docs, validation log, screenshots, deploy zip, and SHA256.

If source and docs disagree, source wins, but update the docs before handoff.
```
