# Safe Patch Template

Use this pattern for future internal patch layers in `no-moon/index.html`:

```js
// === v68 — Short descriptive patch name ===
(function installV68ShortNamePass(){
  const V68_VERSION = 'qual.short-name.2026-xx-xx.v68';
  if (!state || state.v68ShortName?.installed) return;

  const sys = state.v68ShortName = {
    installed: true,
    version: V68_VERSION,
    config: {},
    stats: {}
  };

  function debugPayload() {
    return {
      version: sys.version,
      installed: !!sys.installed,
      buildTag: state.buildTag,
      config: Object.assign({}, sys.config),
      stats: Object.assign({}, sys.stats)
    };
  }

  if (typeof drawHUD === 'function' && !drawHUD.__v68ShortName) {
    const baseDrawHUD = drawHUD;
    drawHUD = function drawHUDV68ShortName(){
      const out = baseDrawHUD.apply(this, arguments);
      try {
        // optional HUD overlay
      } catch (err) {
        try { console.warn('[v68ShortName drawHUD]', err); } catch (_) {}
      }
      return out;
    };
    drawHUD.__v68ShortName = true;
  }

  state.v68ShortNameDebug = debugPayload;
  state.buildTag = V68_VERSION;
  try {
    const tagEl = document.getElementById('buildTagDisplay');
    if (tagEl) tagEl.textContent = 'build: ' + state.buildTag;
  } catch (_) {}
})();
```

Always add debug helpers and validation notes for new patches.
