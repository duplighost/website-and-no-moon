# Source of Truth and Work Rules

## Source of truth

Current version: **v67 — Hazard Literacy + UI/Ending Clarity**

Use `01_CURRENT_WEBSITE_SOURCE_V67/` as the editable source base and `02_CURRENT_DEPLOY_PACKAGE/no-moon-qualiacology-v67-hazard-literacy-ui-ending-clarity.zip` as the current upload-ready package.

This final archive contains no older deploy packages. It contains historical notes only, so there is no stale binary/source snapshot to accidentally start from.

## If you make a new build

When making v68 or any later version:

1. Copy `01_CURRENT_WEBSITE_SOURCE_V67/` into a new working folder.
2. Edit `no-moon/index.html` and related source files as needed.
3. Bump `state.buildTag` in the new patch layer.
4. Bump `/no-moon/no-moon-sw.js` `CACHE_NAME`.
5. Update the service-worker asset list if adding/removing assets.
6. Update root `/no-moon-sw.js` cleanup comment/version.
7. Update the website root `index.html` No Moon description if the public feature copy changes.
8. Produce patch notes, implementation notes, debug helper notes, validation log, screenshots, and SHA256.
9. Run `python3 07_TOOLS/validate_handoff.py` before returning anything.

## Design constraints

- Do not yank camera or control away from the player.
- Keep combat prose minimal; prefer world/UI visual grammar over text.
- Preserve player radius, movement, weapons, and character IDs unless explicitly changing saves.
- Preserve item IDs and achievement IDs if only changing visible copy.
- Keep mobile UI readable.
- Make ground hazards visually clear without turning the game into a label farm.
- Boss presence should use arena rings, phase behavior, boss bar, and room pressure, not forced camera movement.
- Safe Haven should remember progress physically through objects, especially Moon Head and Sun Head trophies.

## Implementation style

Prefer small guarded internal patch layers:

```js
(function installV68ExamplePass(){
  if (!state || state.v68Example?.installed) return;
  const sys = state.v68Example = { installed: true, version: '...' };

  if (typeof drawHUD === 'function' && !drawHUD.__v68Example) {
    const baseDrawHUD = drawHUD;
    drawHUD = function drawHUDV68Example() {
      const out = baseDrawHUD.apply(this, arguments);
      try { /* optional draw logic */ } catch (err) { try { console.warn('[v68]', err); } catch (_) {} }
      return out;
    };
    drawHUD.__v68Example = true;
  }
})();
```

Use `apply(this, arguments)` when wrapping existing functions. Add sentinels such as `__v68Example` so reload/reinstallation does not double-wrap.

## Things to avoid

- Do not start from old version notes instead of current source.
- Do not place gameplay patches outside the main closure.
- Do not change save schema without migration/canonicalization.
- Do not add a new framework/bundler unless Alex explicitly chooses that refactor.
- Do not turn every uncertainty into text. The game direction is visual clarity, not prose spam.
