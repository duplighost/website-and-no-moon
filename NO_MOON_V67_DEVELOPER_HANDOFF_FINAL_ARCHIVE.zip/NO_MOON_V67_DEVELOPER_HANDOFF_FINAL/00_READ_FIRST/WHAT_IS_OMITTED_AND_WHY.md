# What Is Omitted and Why

This final handoff archive is meant to be clean, current, and usable. It intentionally omits:

- Older deploy zips from v56, v63, v64, v65, and v66.
- The bulky v67 backup/notes zip, because the useful notes and screenshots are extracted here.
- Full-resolution generated concept-art image batches.
- Old legacy handoff zips.
- Unrelated personal/song/archive materials.

Historical notes from v63-v67 are retained because they explain the patch lineage without encouraging anyone to accidentally edit from an old deploy package.

If rollback or forensic diffing is needed, ask Alex for the specific older package separately.
