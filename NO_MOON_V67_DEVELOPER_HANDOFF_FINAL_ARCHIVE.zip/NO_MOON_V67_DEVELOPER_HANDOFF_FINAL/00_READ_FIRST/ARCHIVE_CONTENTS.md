# Archive Contents

```text
NO_MOON_V67_DEVELOPER_HANDOFF_FINAL/
├── 00_READ_FIRST/
│   ├── README_START_HERE.md
│   ├── SOURCE_OF_TRUTH_AND_RULES.md
│   ├── ARCHIVE_CONTENTS.md
│   ├── WHAT_IS_OMITTED_AND_WHY.md
│   └── PACKAGE_MANIFEST_SHA256.md
├── 01_CURRENT_WEBSITE_SOURCE_V67/
│   ├── index.html
│   ├── book.html
│   ├── no-moon.html
│   ├── no-moon-sw.js
│   ├── _redirects
│   ├── assets/
│   └── no-moon/
│       ├── index.html
│       └── no-moon-sw.js
├── 02_CURRENT_DEPLOY_PACKAGE/
│   └── no-moon-qualiacology-v67-hazard-literacy-ui-ending-clarity.zip
├── 03_CURRENT_NOTES_AND_VALIDATION/
│   └── v63-v67 notes, debug docs, validation logs, SHA notes
├── 04_CURRENT_SCREENSHOTS/
│   └── current v67 screenshots
├── 05_DESIGN_AND_ART_DIRECTION/
│   ├── DESIGN_BRIEF.md
│   └── ART_AND_ASSET_GUIDE.md
├── 06_CODE_AND_SYSTEMS_GUIDE/
│   └── architecture, systems, save/progress, UI, deployment, roadmap docs
├── 07_TOOLS/
│   └── validate_handoff.py
└── 08_AI_OR_DEV_HANDOFF_PROMPTS/
    ├── PROMPT_FOR_NEXT_AI_OR_DEV.md
    └── SAFE_PATCH_TEMPLATE.md
```

The source folder is extracted from the current deploy zip. It is not polluted with older build folders or extracted helper files. The validation script extracts inline JS on demand into a temporary validation file.
