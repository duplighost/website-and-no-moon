# Start Here — No Moon v67

## What this archive is

This is the final cleaned handoff archive for **No Moon v67**, a static-site browser game under Alex's Qualiacology website. It is intended for another AI instance, a human developer, or a designer/QA collaborator who has not seen the original development thread.

This archive is intentionally context-free: it does not rely on private chat history, missing links, or older deploy packages.

## Current source of truth

Use these as the current base:

1. **Editable current website/game source**
   - `01_CURRENT_WEBSITE_SOURCE_V67/`
   - This folder is extracted directly from the current v67 deploy package.
   - It contains the full static website root, including `/no-moon/index.html`.

2. **Current upload-ready deploy zip**
   - `02_CURRENT_DEPLOY_PACKAGE/no-moon-qualiacology-v67-hazard-literacy-ui-ending-clarity.zip`
   - This is the exact current v67 deploy package.

## Current version markers

- Build tag: `qual.hazard-literacy-ui-ending-clarity.2026-05-10.v67`
- No Moon game service-worker cache: `no-moon-hazard-ui-ending-clarity-v67`
- Current deploy SHA256 is listed in `03_CURRENT_NOTES_AND_VALIDATION/no_moon_v67_sha256.txt`.

## What is included

- Current v67 source and current v67 deploy package.
- Patch notes, implementation notes, validation logs, and debug helper notes from v63-v67.
- Current v67 screenshots.
- Design/art-direction brief.
- Code architecture and systems reference.
- QA/deployment/cache guide.
- Next-work roadmap.
- Validation script.
- A ready-to-paste prompt for another AI/dev.

## What is not included

Older deploy zips are **not** included in this final archive. Historical notes from v63-v67 are included instead. If an older binary is needed for rollback or forensic comparison, ask Alex for it separately.

Unrelated personal/song archives are not included.

## Recommended first reading order

1. `00_READ_FIRST/SOURCE_OF_TRUTH_AND_RULES.md`
2. `06_CODE_AND_SYSTEMS_GUIDE/01_PROJECT_AND_DESIGN_OVERVIEW.md`
3. `06_CODE_AND_SYSTEMS_GUIDE/02_CODE_ARCHITECTURE.md`
4. `06_CODE_AND_SYSTEMS_GUIDE/03_GAMEPLAY_SYSTEMS_REFERENCE.md`
5. `06_CODE_AND_SYSTEMS_GUIDE/08_QA_DEPLOYMENT_AND_CACHE.md`
6. `06_CODE_AND_SYSTEMS_GUIDE/09_KNOWN_RISKS_AND_NEXT_WORK.md`

## Critical warning for implementation

No Moon's game code is mostly inside one huge inline JavaScript closure in `no-moon/index.html`. Most important functions are closure-local, not globals. Gameplay patches should be inserted inside that main script closure, near the bottom, before the final `renderCodexStats();` call. Do not append external gameplay scripts and expect them to reach `drawHUD`, `updateGame`, `damageEnemy`, `pushMessage`, or other closure-local functions.

If source and docs disagree, inspect the current source and update the docs. Source wins.
