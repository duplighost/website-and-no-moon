#!/usr/bin/env python3
from pathlib import Path
import hashlib
import re
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / '01_CURRENT_WEBSITE_SOURCE_V67'
DEPLOY = ROOT / '02_CURRENT_DEPLOY_PACKAGE' / 'no-moon-qualiacology-v67-hazard-literacy-ui-ending-clarity.zip'
EXPECTED_BUILD = 'qual.hazard-literacy-ui-ending-clarity.2026-05-10.v67'
EXPECTED_CACHE = 'no-moon-hazard-ui-ending-clarity-v67'
checks=[]
def check(name, ok): checks.append((name, ok))
print('No Moon v67 final handoff validation')
print('Root:', ROOT)
html=SOURCE/'no-moon'/'index.html'
if html.exists():
    txt=html.read_text(encoding='utf-8',errors='ignore')
    check('source no-moon/index.html exists', True)
    check('expected build tag present in source', EXPECTED_BUILD in txt)
    scripts=re.findall(r'<script[^>]*>(.*?)</script>', txt, flags=re.S|re.I)
    js='\n'.join(scripts)
    temp=ROOT/'07_TOOLS'/'_validation_inline_game.js'
    temp.write_text(js, encoding='utf-8')
    check('inline JS extracted', len(js)>100000)
    try:
        r=subprocess.run(['node','--check',str(temp)],capture_output=True,text=True)
        check('node --check inline game JS', r.returncode==0)
        if r.returncode: print(r.stdout, r.stderr)
    except FileNotFoundError:
        check('node --check inline game JS', None)
else: check('source no-moon/index.html exists', False)
for rel in ['no-moon/no-moon-sw.js','no-moon-sw.js']:
    p=SOURCE/rel
    if p.exists():
        txt=p.read_text(encoding='utf-8',errors='ignore')
        if rel=='no-moon/no-moon-sw.js': check('expected game SW cache name present', EXPECTED_CACHE in txt)
        try:
            r=subprocess.run(['node','--check',str(p)],capture_output=True,text=True)
            check(f'node --check {rel}', r.returncode==0)
            if r.returncode: print(r.stdout, r.stderr)
        except FileNotFoundError:
            check(f'node --check {rel}', None)
    else: check(f'{rel} exists', False)
if DEPLOY.exists():
    try:
        with zipfile.ZipFile(DEPLOY) as z:
            bad=z.testzip(); names=set(z.namelist())
        check('current deploy zip integrity', bad is None)
        for required in ['index.html','no-moon/index.html','no-moon/no-moon-sw.js','assets/no-moon/title/no-moon-title-desktop.webp']:
            check(f'deploy contains {required}', required in names)
        print('Current deploy SHA256:', hashlib.sha256(DEPLOY.read_bytes()).hexdigest())
    except Exception as e:
        print('zip exception', e); check('current deploy zip integrity', False)
else: check('current deploy zip exists', False)
failed=False
for name, ok in checks:
    if ok is None: status='SKIP'
    elif ok: status='PASS'
    else: status='FAIL'; failed=True
    print(f'{status:4} {name}')
if failed: sys.exit(1)
